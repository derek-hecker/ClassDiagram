using System;
using System.Collections.Generic;
using System.Text;

namespace BannerDiagram.Banner
{
	public class Schedule
	{
		public static int numberOfCourses;
		public string[][] CourseNumberToNameMap;

		public void ShowCourses()
		{
			throw new NotImplementedException();
		}

		public void AddCourse(string name, int capacity, int courseNumber)
		{
			throw new NotImplementedException();
		}

		public void DeleteCourse(int courseID)
		{
			throw new NotImplementedException();
		}
	}
}
