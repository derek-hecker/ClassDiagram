using System;
using System.Collections.Generic;
using System.Text;

namespace BannerDiagram.Banner
{
	public class CourseSection : Schedule
	{
		private string Instructor { get; set; }
		private int capacity { get; set; }
		static int courseID { get; set; }

		public CourseSection()
		{
			throw new NotImplementedException();
		}

		~CourseSection()
		{
			throw new NotImplementedException();
		}

		public void Show_Members()
		{
			throw new NotImplementedException();
		}

		public void ShowCourseInfo()
		{
			throw new NotImplementedException();
		}
	}
}
