using System;
using System.Collections.Generic;
using System.Text;

namespace BannerDiagram.Banner
{
	public class Advisor : DSU_Person
	{
		private int AdvisorID { get; set; }
		const string role = "Adv";

		private void listAdvisees()
		{
			throw new NotImplementedException();
		}
		public override void changeEmail()
		{
			Console.WriteLine("Please enter your desired email address");
			string new_email = Console.ReadLine();
			DSU_Email = new_email;
		}
		public void changeEmail(string new_email)
		{
			DSU_Email = new_email;
		}
		public override void changeAddress()
		{
			throw new NotImplementedException();
		}
		public override void viewSchedule()
		{
			throw new NotImplementedException();
		}
		private void removeHold(int studentID, int holdID)
		{
			throw new NotImplementedException();
		}

		private void viewStudentProfile(int studentID)
		{
			throw new NotImplementedException();
		}

		private void DegreeProgress(int studentID)
		{
			throw new NotImplementedException();
		}

		private void viewRegistration(int studentID)
		{
			throw new NotImplementedException();
		}

		public Advisor()
		{

		}

		~Advisor()
		{

		}
	}
}
