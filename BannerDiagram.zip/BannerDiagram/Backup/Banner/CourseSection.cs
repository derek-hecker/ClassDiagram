using System;
using System.Collections.Generic;
using System.Text;

namespace BannerDiagram.Banner
{
	public class CourseSection : Schedule
	{
		private string Instructor;
		private int capacity;
		static int courseID;

		public CourseSection()
		{
			throw new NotImplementedException();
		}

		~CourseSection()
		{
			throw new NotImplementedException();
		}

		public void Show_Members()
		{
			throw new NotImplementedException();
		}

		public void ShowCourseInfo()
		{
			throw new NotImplementedException();
		}
	}
}
