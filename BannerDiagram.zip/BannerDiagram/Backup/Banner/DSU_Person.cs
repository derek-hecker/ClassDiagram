using System;
using System.Collections.Generic;
using System.Text;

namespace BannerDiagram.Banner
{
	public abstract class DSU_Person
	{
		private new string DSU_Email;
		private string Name;

		public DSU_Person()
		{
			throw new NotImplementedException();
		}

		~DSU_Person()
		{
			throw new NotImplementedException();
		}
	}
}
