using System;
using System.Collections.Generic;
using System.Text;

namespace BannerDiagram.Banner
{
	public class Advisor : DSU_Person
	{
		private int AdvisorID;
		const string role = Advisor;

		private void listAdvisees()
		{
			throw new NotImplementedException();
		}

		private void removeHold(int studentID, int holdID)
		{
			throw new NotImplementedException();
		}

		private void viewStudentProfile(int studentID)
		{
			throw new NotImplementedException();
		}

		private void DegreeProgress(int studentID)
		{
			throw new NotImplementedException();
		}

		private void viewRegistration(int studentID)
		{
			throw new NotImplementedException();
		}

		public Advisor()
		{
			throw new NotImplementedException();
		}

		~Advisor()
		{
			throw new NotImplementedException();
		}
	}
}
